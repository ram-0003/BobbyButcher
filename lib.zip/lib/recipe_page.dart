import 'package:flutter/material.dart';

class RecipePage extends StatelessWidget {
  final List<Map<String, String>> recipes = [
    {'title': 'Chicken Curry', 'image': 'lib/assets/ChickenCurry.png'},
    {'title': 'Grilled Chicken', 'image': 'lib/assets/grillChicken.png'},
    {'title': 'Mutton Curry', 'image': 'lib/assets/muttoncurry.png'},
    {'title': 'Chicken Biryani', 'image': 'lib/assets/chickenbiriyani.png'},
    {'title': 'Mutton Biryani', 'image': 'lib/assets/muttonbiriyani.png'},
    {'title': 'Chicken Curry', 'image': 'lib/assets/ChickenCurry.png'},
    {'title': 'Grilled Chicken', 'image': 'lib/assets/grillChicken.png'},
    {'title': 'Mutton Curry', 'image': 'lib/assets/muttoncurry.png'},
  ];

  RecipePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Center(
          child: Text(
            'Recipe Categories',
            style: TextStyle(fontWeight: FontWeight.bold, color: Colors.red),
          ),
        ),
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: GridView.builder(
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            childAspectRatio: 0.8,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
          ),
          itemCount: recipes.length,
          itemBuilder: (context, index) {
            return RecipeCard(
              title: recipes[index]['title']!,
              imageUrl: recipes[index]['image']!,
              onTap: () {
                // Navigate to a specific detail screen based on the recipe title
                switch (recipes[index]['title']) {
                  case 'Chicken Curry':
                  // Navigator.push(
                  //   context,
                  //   MaterialPageRoute(
                  //       builder: (context) => ChickenCurryScreen()),
                  // );
                    break;
                  case 'Grilled Chicken':
                  // Navigator.push(
                  //   context,
                  //   MaterialPageRoute(
                  //       builder: (context) => GrilledChickenScreen()),
                  // );
                    break;
                  case 'Mutton Curry':
                  // Navigator.push(
                  //   context,
                  //   MaterialPageRoute(
                  //       builder: (context) => MuttonCurryScreen()),
                  // );
                    break;
                  case 'Chicken Biryani':
                  // Navigator.push(
                  //   context,
                  //   MaterialPageRoute(
                  //       builder: (context) => ChickenBiriyaniScreen()),
                  // );
                    break;
                  case 'Mutton Biryani':
                  // Navigator.push(
                  //   context,
                  //   MaterialPageRoute(
                  //       builder: (context) => MuttonBiriyaniScreen()),
                  // );
                    break;
                  default:
                    break;
                }
              },
            );
          },
        ),
      ),
    );
  }
}

class RecipeCard extends StatelessWidget {
  final String title;
  final String imageUrl;
  final VoidCallback onTap;

  const RecipeCard({super.key, 
    required this.title,
    required this.imageUrl,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.asset(
                imageUrl,
                fit: BoxFit.cover,
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            title,
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}
